Harrison Ndungu website files

Files:
- index.html: website structure/content
- style.css: styles extracted from the original HTML
- js/script.js: navigation, slideshow, and toast/form interactions
- images/: place local image assets referenced by index.html here

Important:
The original HTML references two local image files:
- image_96c8de.png
- watermarked_img_17789605695146675821.jpg

Copy those files into the images folder, then update the corresponding src values in index.html to:
- images/image_96c8de.png
- images/watermarked_img_17789605695146675821.jpg

Some slideshow and portfolio images use external URLs and therefore require an internet connection.
The contact form currently shows a confirmation in the browser; it does not send email unless connected to a form backend/service.
The CV button currently shows a toast; add your actual CV PDF and link the button to it if you want downloads.
