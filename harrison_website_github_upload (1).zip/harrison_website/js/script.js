/* Navigation Tab Switching */
    function openTab(tabId, element) {
      let pages = document.getElementsByClassName("page-tab");
      for (let i = 0; i < pages.length; i++) {
        pages[i].classList.remove("active-page");
      }

      let buttons = document.getElementsByClassName("nav-tab-btn");
      for (let i = 0; i < buttons.length; i++) {
        if (!buttons[i].classList.contains('eportfolio-link')) {
          buttons[i].classList.remove("active");
        }
      }

      document.getElementById(tabId).classList.add("active-page");
      element.classList.add("active");
    }

    /* Automated Hero Slideshow */
    let slideIndex = 0;
    let timer;

    function showSlides() {
      let slides = document.getElementsByClassName("slide");
      let dots = document.getElementsByClassName("dot");

      for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
      }

      slideIndex++;
      if (slideIndex > slides.length) {
        slideIndex = 1;
      }

      for (let i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
      }

      if (slides[slideIndex - 1]) {
        slides[slideIndex - 1].style.display = "block";
      }
      if (dots[slideIndex - 1]) {
        dots[slideIndex - 1].className += " active";
      }

      timer = setTimeout(showSlides, 4500);
    }

    function setSlide(n) {
      clearTimeout(timer);
      slideIndex = n;
      showSlides();
    }

    showSlides();

    /* Form & Toast Notifications */
    function showToast(msg) {
      const toast = document.getElementById("toast");
      toast.innerText = msg;
      toast.className = "toast show";
      setTimeout(function() { 
        toast.className = toast.className.replace("show", ""); 
      }, 3000);
    }

    function handleFormSubmit(event) {
      event.preventDefault();
      showToast("Thank you! Your message has been sent.");
      event.target.reset();
    }
